package swtest.midtestB;

public enum BMIGrade {
	L,N,H,O,S;
}

package swtest.midtestB;

public interface CheckGroup02 {

}

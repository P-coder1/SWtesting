package swtest.midtestB;

public interface CheckGroup03 {

}

package swtest.midtestB;

public interface CheckGroup01 {

}

package swtest.midtestB;

import org.junit.experimental.categories.Categories.IncludeCategory;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@IncludeCategory({CheckGroup02.class, CheckGroup03.class})
@SuiteClasses({ CheckGroup01.class, CheckGroup02.class, CheckGroup03.class })
public class CTCheackBMIGradeTest {

}

package swtest.midtestB;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ CheckGroup01.class, CheckGroup02.class, CheckGroup03.class })
public class AllcheckBMIGradeTest {

}

package swtest.midtestB;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

public class CheckBMIGradeTest06 {
	CheckBMIGrade che = null;
	
	@Test
	public void test1() throws InvalidInputException {
		che = new CheckBMIGrade();
		che.check_bmi_grade(23, 18);
		assertEquals(BMIGrade.N, che.getGrade());
	}
	
	@Test
	public void test2() throws InvalidInputException {
		che = new CheckBMIGrade();
		che.check_bmi_grade(24, 23);
		assertEquals(BMIGrade.H, che.getGrade());
	}
	
	@Test
	public void test3() throws InvalidInputException {
		che = new CheckBMIGrade();
		che.check_bmi_grade(25, 24);
		assertEquals(BMIGrade.O, che.getGrade());
	}
	
	@Test
	public void test4() throws InvalidInputException {
		che = new CheckBMIGrade();
		che.check_bmi_grade(30, 25);
		assertEquals(BMIGrade.S, che.getGrade());
	}
	
	@Test(expected = InvalidInputException.class)
	public void test5() throws InvalidInputException {
		che = new CheckBMIGrade();
		che.check_bmi_grade(40, 0);
		assertEquals(BMIGrade.S, che.getGrade());
	}
	@Test(expected = InvalidInputException.class)
	public void test6() throws InvalidInputException {
		che = new CheckBMIGrade();
		che.check_bmi_grade(41, 0);
		assertEquals(BMIGrade.S, che.getGrade());
	}
	@Test(expected = InvalidInputException.class)
	public void test7() throws InvalidInputException {
		che = new CheckBMIGrade();
		che.check_bmi_grade(42, 0);
		assertEquals(BMIGrade.S, che.getGrade());
	}
	@Test(expected = InvalidInputException.class)
	public void test8() throws InvalidInputException {
		che = new CheckBMIGrade();
		che.check_bmi_grade(50, 0);
		assertEquals(BMIGrade.S, che.getGrade());
	}
	
}



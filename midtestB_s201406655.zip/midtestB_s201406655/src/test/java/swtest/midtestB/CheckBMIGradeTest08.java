package swtest.midtestB;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

public class CheckBMIGradeTest08 {
	
	@Category(CheckGroup03.class)
	@RunWith(Parameterized.class)
	public static class BMICTest {
	
		BMIGrade grade;
		int age;
		double bmi;
		
		@Parameters
		public static Collection getParameters() {
			return Arrays.asList(new Object[][] {
				{BMIGrade.N, 16, 20},
				{BMIGrade.L, 15, 20},
				{BMIGrade.N, 29, 20},
				{BMIGrade.N, 30, 20},
				{BMIGrade.H, 20, 24},
				{BMIGrade.N, 20, 23},
				{BMIGrade.S ,18 ,40},
				{BMIGrade.S ,18 ,41},
				{BMIGrade.S ,18 ,42},
				{BMIGrade.S ,18 ,50}
			});
		}
		
		
		public BMICTest(BMIGrade grade, int age, double bmi) {
			this.age= age;
			this.bmi= bmi;
			this.grade= grade;
		}
		@Test(expected = InvalidInputException.class)
		public void test_calculate_bmi_with_invalid_bmi() throws InvalidInputException {
			CheckBMIGrade che = null;
			che = new CheckBMIGrade();
			che.check_bmi_grade(bmi, age); 
			assertEquals(grade, che.getGrade()); 
		}
	}
}

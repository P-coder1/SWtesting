package swtest.midtestB;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

public class CheckBMIGradeTest07 {
	
	@Category(CheckGroup02.class)
	@RunWith(Parameterized.class)
	public static class BMIBTest {
		
		BMIGrade grade;
		int age;
		double bmi;
		
		@Parameters
		public static Collection getParameters() {
			return Arrays.asList(new Object[][] {
				{BMIGrade.L ,16 ,17},
				{BMIGrade.N ,17 ,19},
				{BMIGrade.H ,22 ,24},
				{BMIGrade.O ,25 ,26},
				{BMIGrade.S ,29 ,36},
				{BMIGrade.L ,16 ,18},
				{BMIGrade.N ,18 ,22},
				{BMIGrade.H ,19 ,24},
				{BMIGrade.H ,20 ,24},
				{BMIGrade.H ,23 ,24}
			});
		}
		
		
		public BMIBTest(BMIGrade grade, int age, double bmi) {
			this.age= age;
			this.bmi= bmi;
			this.grade= grade;
		}
		@Test(expected = InvalidInputException.class)
		public void test_calculate_bmi_with_invalid_bmi() throws InvalidInputException {
			CheckBMIGrade che = null;
			che = new CheckBMIGrade();
			che.check_bmi_grade(bmi, age); 
			assertEquals(grade, che.getGrade()); 
		}
	}
}

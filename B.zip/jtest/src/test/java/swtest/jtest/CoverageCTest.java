package swtest.jtest;

import static org.junit.Assert.*;

import org.junit.Test;

public class CoverageCTest {

	@Test
	public void testCoverage1() {
		CoverageC covc = new CoverageC();
		
		cov.coveagem(15,15,15);
	}

}
